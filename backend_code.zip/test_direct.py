from aws_service import get_aws_costs
from database import SessionLocal
from main import fetch_costs

def test():
    print("Testing get_aws_costs()...")
    res = get_aws_costs()
    print("Result:", res)

    print("\nTesting fetch_costs() with DB session...")
    db = SessionLocal()
    try:
        app_res = fetch_costs(db)
        print("Fetch Costs Result:", app_res)
    except Exception as e:
        print("Fetch Costs Error:", str(e))
    finally:
        db.close()

if __name__ == "__main__":
    test()
