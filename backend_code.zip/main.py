from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
import models
from database import engine, SessionLocal
from aws_service import get_aws_costs  # Removed the 'Services.' prefix

# Initialize DB
models.Base.metadata.create_all(bind=engine)

app = FastAPI()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/")
def home():
    return {"message": "AuraOpt Backend is Running"}

@app.get("/fetch-costs")
def fetch_costs(db: Session = Depends(get_db)):
    # 1. Get data from AWS
    aws_response = get_aws_costs()
    
    if "error" in aws_response:
        return aws_response

    # 2. Save each daily cost to the SQLite database
    for item in aws_response['data']:
        new_cost = models.Cost(
            date=item['date'], 
            cost=item['amount']
        )
        db.add(new_cost)
    
    db.commit()
    return aws_response