import os
import boto3
from dotenv import load_dotenv
from pathlib import Path
from datetime import datetime, timedelta

# Load credentials from the .env file in the current directory
env_path = Path(__file__).parent / ".env"
load_dotenv(dotenv_path=env_path)

def get_aws_costs():
    access_key = os.getenv("AWS_ACCESS_KEY_ID")
    secret_key = os.getenv("AWS_SECRET_ACCESS_KEY")
    region = "us-east-1" 

    if not access_key or not secret_key:
        return {"error": "Credentials missing in .env"}

    try:
        # STRATEGY 1: Try true Cost Explorer (Needs 24hrs for new AWS accounts)
        ce = boto3.client(
            'ce',
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            region_name=region
        )

        response = ce.get_cost_and_usage(
            TimePeriod={
                'Start': (datetime.utcnow() - timedelta(days=30)).strftime('%Y-%m-%d'), 
                'End': datetime.utcnow().strftime('%Y-%m-%d')
            },
            Granularity='DAILY',
            Metrics=['UnblendedCost']
        )

        results = []
        for day in response['ResultsByTime']:
            results.append({
                "date": day['TimePeriod']['Start'],
                "amount": float(day['Total']['UnblendedCost']['Amount']),
                "unit": day['Total']['UnblendedCost']['Unit']
            })
        
        if not results:
            raise Exception("No data found in Cost Explorer range")

        return {"status": "success", "source": "aws_cost_explorer", "data": results}

    except Exception as e:
        print(f"AWS Cost Explorer Unavailable: {e}")
        
        # STRATEGY 2: Try CloudWatch Billing Metrics 
        # (Works immediately IF you enabled 'Receive Billing Alerts' in AWS Billing Console)
        print("Falling back to CloudWatch EstimatedCharges metric...")
        try:
            cloudwatch = boto3.client(
                'cloudwatch',
                aws_access_key_id=access_key,
                aws_secret_access_key=secret_key,
                region_name=region
            )
            
            cw_response = cloudwatch.get_metric_statistics(
                Namespace='AWS/Billing',
                MetricName='EstimatedCharges',
                Dimensions=[
                    {'Name': 'Currency', 'Value': 'USD'}
                ],
                StartTime=datetime.utcnow() - timedelta(days=5),
                EndTime=datetime.utcnow(),
                Period=86400, # Daily max
                Statistics=['Maximum']
            )

            cw_results = []
            for dp in sorted(cw_response['Datapoints'], key=lambda x: x['Timestamp']):
                cw_results.append({
                    "date": dp['Timestamp'].strftime('%Y-%m-%d'),
                    "amount": float(dp['Maximum']),
                    "unit": "USD"
                })
                
            if cw_results:
                return {"status": "success", "source": "aws_cloudwatch_billing", "data": cw_results}
            else:
                print("No CloudWatch Billing data found. Ensure 'Receive Billing Alerts' is enabled in AWS Billing preferences.")
                
        except Exception as cw_e:
            print(f"CloudWatch fallback failed: {cw_e}")

        # STRATEGY 3: Mock Data Fallback 
        # Ensures your app NEVER crashes during demos even if AWS is totally unconfigured.
        mock_data = [
            {"date": (datetime.utcnow() - timedelta(days=3)).strftime('%Y-%m-%d'), "amount": 0.45, "unit": "USD"},
            {"date": (datetime.utcnow() - timedelta(days=2)).strftime('%Y-%m-%d'), "amount": 1.20, "unit": "USD"},
            {"date": (datetime.utcnow() - timedelta(days=1)).strftime('%Y-%m-%d'), "amount": 5.80, "unit": "USD"},
            {"date": datetime.utcnow().strftime('%Y-%m-%d'), "amount": 0.55, "unit": "USD"},
        ]
        return {
            "status": "success", 
            "source": "simulation_mode", 
            "note": "AWS Cost Explorer pending & CloudWatch alerts disabled. Using realistic fallback data.",
            "data": mock_data
        }