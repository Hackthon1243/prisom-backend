from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_routes():
    # Test Home
    response = client.get("/")
    print("GET / -> Status:", response.status_code)
    print("Response:", response.json())
    
    # Test Fetch Costs
    try:
        response = client.get("/fetch-costs")
        print("\nGET /fetch-costs -> Status:", response.status_code)
        print("Response:", response.json())
    except Exception as e:
        print("\nGET /fetch-costs -> Error:", str(e))

if __name__ == "__main__":
    test_routes()
