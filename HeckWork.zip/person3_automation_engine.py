"""
PERSON 3: AWS Automation Engineer
Input: data/ml_results.csv (from Person 2)
Output: logs/automation_actions.log
"""

import os
import sys
import logging
import pandas as pd

# Import shared config
from config import (
    ML_RESULTS_CSV, AUTOMATION_LOG, DRY_RUN_MODE,
    ENABLE_ACTUAL_TERMINATION, REQUIRE_APPROVAL, LOG_FORMAT, LOG_LEVEL
)

# Setup logging to both console and file
logging.basicConfig(level=LOG_LEVEL, format=LOG_FORMAT)
logger = logging.getLogger(__name__)

# Add file handler for automation log
os.makedirs("logs", exist_ok=True)
file_handler = logging.FileHandler(AUTOMATION_LOG)
file_handler.setFormatter(logging.Formatter(LOG_FORMAT))
logger.addHandler(file_handler)

class AutomationEngine:
    """Execute automated optimizations based on Person 2's ML results"""
    
    def __init__(self):
        self.actions_log = []
    
    def find_idle_instances(self, df):
        """Identify idle instances from Person 2's anomalies"""
        logger.info("🔍 Finding idle instances from ML analysis...")
        
        if 'Is_Anomalous' not in df.columns:
            logger.error("❌ Is_Anomalous column not found in Person 2's data")
            return []
        
        # Find anomalous instances with low CPU
        if 'CPU_Usage_Percent' in df.columns:
            idle = df[
                (df['Is_Anomalous']) & 
                (df['CPU_Usage_Percent'] < 5)
            ]['Resource_ID'].unique()
        else:
            idle = df[df['Is_Anomalous']]['Resource_ID'].unique()
        
        logger.info(f"✅ Found {len(idle)} idle instance candidates")
        return idle.tolist()
    
    def execute_optimizations(self, df):
        """Execute automation based on Person 2's ML"""
        logger.info("\n⚙️  EXECUTING AUTOMATED OPTIMIZATIONS")
        logger.info("-" * 70)
        
        idle_instances = self.find_idle_instances(df)
        
        if not idle_instances:
            logger.info("✅ No idle instances detected - system running efficiently!")
            return
        
        for instance_id in idle_instances:
            self._optimize_instance(instance_id)
    
    def _optimize_instance(self, instance_id):
        """Optimize a single instance"""
        logger.info(f"🔧 Optimizing: {instance_id}")
        
        if DRY_RUN_MODE:
            logger.info(f"   🔴 [DRY RUN] Would stop: {instance_id}")
            action = {
                'instance': instance_id,
                'action': 'STOP',
                'status': 'DRY_RUN',
                'savings_per_hour': 0.50
            }
        elif ENABLE_ACTUAL_TERMINATION:
            # In real scenario, would call AWS API here
            # For now, just log it
            logger.info(f"   ✅ STOPPED instance: {instance_id}")
            action = {
                'instance': instance_id,
                'action': 'STOP',
                'status': 'SUCCESS',
                'savings_per_hour': 0.50
            }
        else:
            logger.warning(f"   ⚠️  Termination disabled. Would stop: {instance_id}")
            action = {
                'instance': instance_id,
                'action': 'STOP',
                'status': 'DISABLED',
                'savings_per_hour': 0.50
            }
        
        self.actions_log.append(action)
    
    def generate_savings_report(self):
        """Generate savings report"""
        logger.info("\n" + "=" * 70)
        logger.info("💰 OPTIMIZATION SAVINGS REPORT")
        logger.info("=" * 70)
        
        if not self.actions_log:
            logger.info("No optimizations performed")
            return
        
        total_hourly = sum(a.get('savings_per_hour', 0) for a in self.actions_log)
        monthly_savings = total_hourly * 24 * 30
        
        logger.info(f"✅ Actions taken: {len(self.actions_log)}")
        logger.info(f"💵 Estimated hourly savings: ${total_hourly:.2f}")
        logger.info(f"💵 Estimated monthly savings: ${monthly_savings:.2f}")

def run_person3_pipeline():
    """Main orchestration for Person 3"""
    logger.info("=" * 70)
    logger.info("👤 PERSON 3: AUTOMATION ENGINE")
    logger.info("=" * 70)
    
    # Load Person 2's ML results
    try:
        df = pd.read_csv(ML_RESULTS_CSV)
        logger.info(f"✅ Loaded {len(df)} rows from Person 2's ML results")
    except FileNotFoundError:
        logger.error(f"❌ {ML_RESULTS_CSV} not found!")
        logger.error("   Person 2 must run first: python main.py --person 2")
        return
    except Exception as e:
        logger.error(f"❌ Error loading ML results: {e}")
        return
    
    # Execute automation
    engine = AutomationEngine()
    engine.execute_optimizations(df)
    engine.generate_savings_report()
    
    logger.info("=" * 70)
    logger.info("✅ PERSON 3 COMPLETE - Logs ready for Person 4")
    logger.info("=" * 70)

if __name__ == "__main__":
    run_person3_pipeline()