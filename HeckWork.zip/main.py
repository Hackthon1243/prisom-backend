"""
MAIN ORCHESTRATOR
Runs all 4 modules in sequence or individually
Usage:
  python main.py              # Run all 4 people
  python main.py --person 1   # Run only Person 1
  python main.py --person 2   # Run only Person 2
  etc.
"""

import sys
import logging
from config import LOG_FORMAT, LOG_LEVEL

logging.basicConfig(level=LOG_LEVEL, format=LOG_FORMAT)
logger = logging.getLogger(__name__)

# Import all modules
from person1_data_pipeline import run_person1_pipeline
from person2_ml_analytics import run_person2_pipeline
from person3_automation_engine import run_person3_pipeline

def run_all():
    """Run all 4 people in sequence"""
    logger.info("\n" + "=" * 70)
    logger.info("🚀 RUNNING COMPLETE PIPELINE (All 4 People)")
    logger.info("=" * 70 + "\n")
    
    # Person 1
    logger.info("\n" + "🔵" * 35)
    run_person1_pipeline()
    
    # Person 2
    logger.info("\n" + "🟢" * 35)
    run_person2_pipeline()
    
    # Person 3
    logger.info("\n" + "🟡" * 35)
    run_person3_pipeline()
    
    logger.info("\n" + "=" * 70)
    logger.info("✅ ALL 3 MODULES COMPLETE!")
    logger.info("=" * 70)
    logger.info("\nTo view dashboard: streamlit run person4_dashboard.py")

def run_person(person_num):
    """Run a specific person's module"""
    if person_num == 1:
        logger.info("Running Person 1...")
        run_person1_pipeline()
    elif person_num == 2:
        logger.info("Running Person 2...")
        run_person2_pipeline()
    elif person_num == 3:
        logger.info("Running Person 3...")
        run_person3_pipeline()
    elif person_num == 4:
        logger.info("Launching Person 4 Dashboard...")
        logger.info("Run: streamlit run person4_dashboard.py")
    else:
        logger.error(f"❌ Unknown person: {person_num}")

def main():
    """Main entry point"""
    if len(sys.argv) > 1:
        if sys.argv[1] == "--person" and len(sys.argv) > 2:
            person_num = int(sys.argv[2])
            run_person(person_num)
        elif sys.argv[1] == "--all":
            run_all()
        else:
            print("Usage:")
            print("  python main.py              # Run all 4 people")
            print("  python main.py --person 1   # Run only Person 1")
            print("  python main.py --person 2   # Run only Person 2")
            print("  python main.py --person 3   # Run only Person 3")
            print("  python main.py --person 4   # Launch dashboard")
    else:
        run_all()

if __name__ == "__main__":
    main()