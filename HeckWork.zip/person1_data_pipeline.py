"""
PERSON 1: Cloud Data Pipeline Engineer
Input: AWS APIs or synthetic generation
Output: data/cloud_costs.db (SQLite database)
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import sqlite3

# Import shared config
from config import (
    DATA_DIR, DB_FILE, USE_REAL_AWS_DATA, DAYS_LOOKBACK,
    ANALYSIS_START_DATE, ANALYSIS_END_DATE, LOG_FORMAT, LOG_LEVEL
)

logging.basicConfig(level=LOG_LEVEL, format=LOG_FORMAT)
logger = logging.getLogger(__name__)

def generate_synthetic_data(days=30, num_resources=8):
    """Generate realistic synthetic cloud cost data"""
    logger.info(f"📊 Generating synthetic data for {days} days...")
    
    np.random.seed(42)
    data = []
    services = ['EC2', 'RDS', 'S3', 'Lambda', 'DynamoDB', 'CloudFront', 'VPC', 'IAM']
    
    for day_offset in range(days):
        current_date = (datetime.now() - timedelta(days=days-day_offset)).strftime("%Y-%m-%d")
        
        for i in range(num_resources):
            service = services[i % len(services)]
            resource_id = f"{service.lower()}-instance-{i:03d}"
            base_cost = np.random.uniform(5, 50)
            
            # Weekday multiplier
            day_of_week = datetime.strptime(current_date, "%Y-%m-%d").weekday()
            weekday_multiplier = 1.2 if day_of_week < 5 else 0.9
            
            # Random daily variance
            daily_noise = np.random.normal(1.0, 0.15)
            
            # Inject anomalies
            is_anomaly = False
            if 20 <= day_offset <= 25 and i == 1:
                cost = base_cost * weekday_multiplier * daily_noise * 0.3
                cpu_usage = np.random.uniform(0.5, 3.0)
                is_anomaly = True
            elif 26 <= day_offset <= 28 and i == 3:
                cost = base_cost * weekday_multiplier * daily_noise * 4
                cpu_usage = np.random.uniform(70, 95)
                is_anomaly = True
            elif 15 <= day_offset <= 18 and i == 5:
                cost = base_cost * weekday_multiplier * daily_noise * 1.5
                cpu_usage = np.random.uniform(30, 50)
                is_anomaly = True
            else:
                cost = base_cost * weekday_multiplier * daily_noise
                cpu_usage = np.random.uniform(40, 75)
            
            cost = max(cost, 0.5)
            
            data.append({
                'Date': current_date,
                'Service': service,
                'Resource_ID': resource_id,
                'Cost': round(cost, 2),
                'CPU_Usage_Percent': round(cpu_usage, 1),
                'Network_Traffic_GB': round(np.random.uniform(0.1, 50), 2),
                'Storage_GB': round(np.random.uniform(10, 500), 1),
                'Is_Anomaly': is_anomaly
            })
    
    df = pd.DataFrame(data)
    logger.info(f"✅ Generated {len(df)} rows")
    return df

def save_to_database(df):
    """Save data to SQLite database"""
    logger.info(f"💾 Saving to {DB_FILE}...")
    try:
        conn = sqlite3.connect(DB_FILE)
        df.to_sql('cloud_costs', conn, if_exists='replace', index=False)
        conn.close()
        logger.info("✅ Data saved to SQLite")
    except Exception as e:
        logger.error(f"❌ Failed: {e}")

def run_person1_pipeline():
    """Main orchestration for Person 1"""
    logger.info("=" * 70)
    logger.info("👤 PERSON 1: DATA PIPELINE")
    logger.info("=" * 70)
    
    if USE_REAL_AWS_DATA:
        logger.info("📡 Using REAL AWS data (not implemented yet)")
        df = generate_synthetic_data()
    else:
        logger.info("📊 Using SYNTHETIC data")
        df = generate_synthetic_data()
    
    # Clean data
    df = df.dropna()
    df = df[df['Cost'] > 0]
    
    # Save to database
    save_to_database(df)
    
    logger.info("=" * 70)
    logger.info("✅ PERSON 1 COMPLETE - Data ready for Person 2")
    logger.info("=" * 70)
    
    return df

if __name__ == "__main__":
    df = run_person1_pipeline()
    print(f"\n📊 Generated data shape: {df.shape}")
    print(f"📊 Sample:\n{df.head()}")