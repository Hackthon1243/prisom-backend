"""
PERSON 4: Dashboard & UX Designer
Input: All outputs from Person 2 & 3
Output: Interactive Streamlit dashboard at http://localhost:8501
"""

import os
import logging
import pandas as pd
import plotly.graph_objects as go

try:
    import streamlit as st
except ImportError:
    print("Installing Streamlit...")
    os.system("pip install streamlit")
    import streamlit as st

# Import shared config
from config import (
    ML_RESULTS_CSV, FORECAST_CSV, ROOT_CAUSES_CSV, AUTOMATION_LOG,
    COLORS, DASHBOARD_REFRESH_SECONDS, LOG_FORMAT, LOG_LEVEL
)

logging.basicConfig(level=LOG_LEVEL, format=LOG_FORMAT)
logger = logging.getLogger(__name__)

# Page configuration
st.set_page_config(
    page_title="☁️ Cloud Cost Intelligence",
    page_icon="💰",
    layout="wide",
    initial_sidebar_state="expanded"
)

@st.cache_data
def load_all_data():
    """Load data from Person 2 & 3"""
    try:
        ml_results = pd.read_csv(ML_RESULTS_CSV)
        logger.info(f"✅ Loaded ML results: {len(ml_results)} rows")
    except FileNotFoundError:
        logger.error(f"❌ {ML_RESULTS_CSV} not found")
        ml_results = pd.DataFrame()
    
    try:
        forecast = pd.read_csv(FORECAST_CSV)
        logger.info(f"✅ Loaded forecast: {len(forecast)} rows")
    except FileNotFoundError:
        logger.warning(f"⚠️  {FORECAST_CSV} not found")
        forecast = pd.DataFrame()
    
    try:
        root_causes = pd.read_csv(ROOT_CAUSES_CSV)
        logger.info(f"✅ Loaded root causes: {len(root_causes)} rows")
    except FileNotFoundError:
        logger.warning(f"⚠️  {ROOT_CAUSES_CSV} not found")
        root_causes = pd.DataFrame()
    
    try:
        with open(AUTOMATION_LOG, 'r') as f:
            automation_log = f.read()
        logger.info(f"✅ Loaded automation log")
    except FileNotFoundError:
        logger.warning(f"⚠️  {AUTOMATION_LOG} not found")
        automation_log = "No automation log yet"
    
    return ml_results, forecast, root_causes, automation_log

def header_section():
    """Display header"""
    col1, col2 = st.columns([3, 1])
    
    with col1:
        st.markdown("# ☁️ Cloud Cost Intelligence Dashboard")
        st.markdown("Real-time anomaly detection, forecasting, and automated cost optimization")
    
    with col2:
        st.markdown("### Status")
        st.success("✅ System Running")
    
    st.markdown("---")

def key_metrics_section(df):
    """Display KPI cards"""
    if df.empty:
        st.warning("⚠️  No data loaded yet. Run the pipeline first!")
        return
    
    col1, col2, col3, col4 = st.columns(4)
    
    total_cost = df['Cost'].sum()
    num_anomalies = df['Is_Anomalous'].sum() if 'Is_Anomalous' in df.columns else 0
    num_resources = df['Resource_ID'].nunique()
    daily_avg = df.groupby('Date')['Cost'].sum().mean()
    
    with col1:
        st.metric("💰 Total Cost", f"${total_cost:,.2f}", "Last 30 days")
    
    with col2:
        st.metric("⚠️  Anomalies", int(num_anomalies), "Detected")
    
    with col3:
        st.metric("☁️ Resources", int(num_resources), "Active")
    
    with col4:
        st.metric("📊 Daily Avg", f"${daily_avg:,.2f}", "Per day")

def cost_trend_section(df):
    """Display cost trend chart"""
    st.subheader("📈 Cost Trend Over Time")
    
    if df.empty:
        st.warning("No data available")
        return
    
    daily_cost = df.groupby('Date').agg({
        'Cost': 'sum',
        'Resource_ID': 'count'
    }).reset_index()
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=daily_cost['Date'],
        y=daily_cost['Cost'],
        fill='tozeroy',
        mode='lines+markers',
        name='Daily Cost',
        line=dict(color=COLORS['normal'], width=2),
        fillcolor=f"rgba(0, 217, 255, 0.1)"
    ))
    
    if 'Is_Anomalous' in df.columns:
        anomaly_dates = df[df['Is_Anomalous']].groupby('Date')['Cost'].sum()
        if not anomaly_dates.empty:
            fig.add_trace(go.Scatter(
                x=anomaly_dates.index,
                y=anomaly_dates.values,
                mode='markers',
                name='Anomalies',
                marker=dict(color=COLORS['anomaly'], size=10),
            ))
    
    fig.update_layout(
        template='plotly_dark',
        hovermode='x unified',
        height=400,
        margin=dict(l=0, r=0, t=30, b=0)
    )
    
    st.plotly_chart(fig, use_container_width=True)

def main():
    """Main dashboard"""
    ml_results, forecast, root_causes, automation_log = load_all_data()
    
    # Header
    header_section()
    
    # Key metrics
    key_metrics_section(ml_results)
    
    # Tabs
    tab1, tab2, tab3, tab4 = st.tabs([
        "📊 Overview",
        "🔮 Forecast",
        "💸 Breakdown",
        "🚨 Anomalies"
    ])
    
    with tab1:
        st.subheader("Cost Trend")
        cost_trend_section(ml_results)
    
    with tab2:
        st.subheader("7-Day Cost Forecast")
        if not forecast.empty:
            st.dataframe(forecast, use_container_width=True)
        else:
            st.warning("No forecast data available")
    
    with tab3:
        st.subheader("Cost by Service")
        if not ml_results.empty:
            service_cost = ml_results.groupby('Service')['Cost'].sum().sort_values(ascending=False)
            st.bar_chart(service_cost)
        else:
            st.warning("No data available")
    
    with tab4:
        st.subheader("Detected Anomalies")
        if not root_causes.empty:
            st.dataframe(root_causes, use_container_width=True)
        else:
            st.warning("No anomalies detected yet")
    
    # Automation log
    st.markdown("---")
    st.subheader("🤖 Automation Log")
    if automation_log and automation_log != "No automation log yet":
        st.code(automation_log[-1000:])
    else:
        st.info("No automation actions logged yet")

if __name__ == "__main__":
    main()