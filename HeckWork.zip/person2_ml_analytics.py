"""
PERSON 2: ML/Analytics Specialist
Input: data/cloud_costs.db (from Person 1)
Output: 
  - data/ml_results.csv (anomalies)
  - data/forecast.csv (7-day forecast)
  - data/root_causes.csv (root cause analysis)
"""

import os
import sys
import logging
import pandas as pd
import numpy as np
import sqlite3
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

try:
    from prophet import Prophet
except ImportError:
    logging.warning("Installing Prophet...")
    os.system("pip install prophet")
    from prophet import Prophet

# Import shared config
from config import (
    DB_FILE, ML_RESULTS_CSV, FORECAST_CSV, ROOT_CAUSES_CSV,
    ANOMALY_CONTAMINATION, ANOMALY_RANDOM_STATE, PROPHET_FORECAST_PERIODS,
    MIN_CPU_THRESHOLD, LOG_FORMAT, LOG_LEVEL
)

logging.basicConfig(level=LOG_LEVEL, format=LOG_FORMAT)
logger = logging.getLogger(__name__)

def load_data_from_person1():
    """Load Person 1's database"""
    logger.info(f"📂 Loading data from Person 1's database...")
    try:
        conn = sqlite3.connect(DB_FILE)
        df = pd.read_sql("SELECT * FROM cloud_costs", conn)
        conn.close()
        logger.info(f"✅ Loaded {len(df)} rows")
        return df
    except FileNotFoundError:
        logger.error(f"❌ {DB_FILE} not found!")
        logger.error("   Person 1 must run first: python main.py --person 1")
        return None
    except Exception as e:
        logger.error(f"❌ Error loading database: {e}")
        return None

class AnomalyDetector:
    """Isolation Forest for anomaly detection"""
    
    def __init__(self, contamination=ANOMALY_CONTAMINATION):
        self.contamination = contamination
        self.model = None
        self.scaler = None
    
    def prepare_features(self, df):
        """Create features for anomaly detection"""
        logger.info("🔧 Preparing features...")
        
        df = df.sort_values(['Resource_ID', 'Date']).reset_index(drop=True)
        
        df['Cost_Change'] = df.groupby('Resource_ID')['Cost'].diff().fillna(0)
        df['Cost_MA7'] = df.groupby('Resource_ID')['Cost'].transform(
            lambda x: x.rolling(window=7, min_periods=1).mean()
        )
        df['Cost_Deviation'] = abs(df['Cost'] - df['Cost_MA7'])
        
        if 'CPU_Usage_Percent' in df.columns:
            df['CPU_Deviation'] = abs(df['CPU_Usage_Percent'] - 50)
        else:
            df['CPU_Deviation'] = 0
        
        return df
    
    def fit(self, df):
        """Train Isolation Forest"""
        logger.info("🧠 Training Isolation Forest...")
        
        df = self.prepare_features(df)
        
        feature_cols = ['Cost', 'Cost_Change', 'Cost_Deviation', 'CPU_Deviation']
        X = df[feature_cols].fillna(0).replace([np.inf, -np.inf], 0)
        
        self.scaler = StandardScaler()
        X_scaled = self.scaler.fit_transform(X)
        
        self.model = IsolationForest(
            contamination=self.contamination,
            random_state=ANOMALY_RANDOM_STATE,
            n_estimators=100
        )
        
        predictions = self.model.fit_predict(X_scaled)
        scores = self.model.score_samples(X_scaled)
        
        df['Anomaly_Score'] = scores
        df['Anomaly_Flag'] = predictions
        df['Is_Anomalous'] = df['Anomaly_Flag'] == -1
        
        logger.info(f"✅ Trained. Found {df['Is_Anomalous'].sum()} anomalies")
        return df

class CostForecaster:
    """Prophet for 7-day forecasting"""
    
    def __init__(self, periods=PROPHET_FORECAST_PERIODS):
        self.periods = periods
        self.models = {}
    
    def fit(self, df):
        """Train Prophet on each resource"""
        logger.info("🔮 Training Prophet forecasts...")
        
        resources = df['Resource_ID'].unique()
        
        for resource_id in resources:
            resource_data = df[df['Resource_ID'] == resource_id].copy()
            forecast_df = resource_data[['Date', 'Cost']].copy()
            forecast_df.columns = ['ds', 'y']
            forecast_df['ds'] = pd.to_datetime(forecast_df['ds'])
            
            try:
                model = Prophet(yearly_seasonality=False, weekly_seasonality=True, interval_width=0.95)
                with open(os.devnull, 'w') as devnull:
                    sys.stderr = devnull
                    model.fit(forecast_df)
                    sys.stderr = sys.__stderr__
                self.models[resource_id] = model
            except Exception as e:
                logger.warning(f"   ⚠️  Failed for {resource_id}: {e}")
        
        logger.info(f"✅ Trained {len(self.models)} models")
        return self.models
    
    def forecast(self):
        """Generate forecasts"""
        logger.info(f"📊 Generating {self.periods}-day forecasts...")
        
        all_forecasts = []
        for resource_id, model in self.models.items():
            try:
                future = model.make_future_dataframe(periods=self.periods)
                with open(os.devnull, 'w') as devnull:
                    sys.stderr = devnull
                    forecast = model.predict(future)
                    sys.stderr = sys.__stderr__
                future_forecast = forecast[forecast['ds'] > pd.Timestamp.now()].copy()
                future_forecast['Resource_ID'] = resource_id
                all_forecasts.append(future_forecast[['ds', 'yhat', 'yhat_lower', 'yhat_upper', 'Resource_ID']])
            except Exception as e:
                logger.warning(f"   ⚠️  Forecast failed for {resource_id}: {e}")
        
        if all_forecasts:
            combined = pd.concat(all_forecasts, ignore_index=True)
            logger.info(f"✅ Generated {len(combined)} forecast points")
            return combined
        else:
            return pd.DataFrame()

class RootCauseAnalyzer:
    """Identify why anomalies happened"""
    
    @staticmethod
    def analyze(df):
        """Analyze anomalies"""
        logger.info("🔍 Analyzing root causes...")
        
        anomaly_df = df[df['Is_Anomalous']].copy() if 'Is_Anomalous' in df.columns else df[df['Anomaly_Flag'] == -1].copy()
        
        if len(anomaly_df) == 0:
            logger.info("   No anomalies found")
            return pd.DataFrame()
        
        analysis = []
        for idx, row in anomaly_df.iterrows():
            cpu_usage = row.get('CPU_Usage_Percent', 50)
            if cpu_usage < MIN_CPU_THRESHOLD:
                anomaly_type = "IDLE_RESOURCE"
                reason = f"CPU very low ({cpu_usage:.1f}%) but cost still high"
            else:
                anomaly_type = "COST_SPIKE"
                reason = f"Unexpected cost surge (${row['Cost']:.2f})"
            
            analysis.append({
                'Date': row['Date'],
                'Resource_ID': row['Resource_ID'],
                'Service': row['Service'],
                'Cost': row['Cost'],
                'Anomaly_Type': anomaly_type,
                'Reason': reason,
                'Anomaly_Score': row.get('Anomaly_Score', 0),
            })
        
        result_df = pd.DataFrame(analysis)
        logger.info(f"✅ Analyzed {len(result_df)} anomalies")
        return result_df

def run_person2_pipeline():
    """Main orchestration for Person 2"""
    logger.info("=" * 70)
    logger.info("👤 PERSON 2: ML ANALYTICS")
    logger.info("=" * 70)
    
    # Load Person 1's data
    df = load_data_from_person1()
    if df is None:
        return None, None, None
    
    # Anomaly detection
    logger.info("\n🔴 ANOMALY DETECTION")
    logger.info("-" * 70)
    detector = AnomalyDetector()
    df = detector.fit(df)
    
    # Forecasting
    logger.info("\n🟢 COST FORECASTING")
    logger.info("-" * 70)
    forecaster = CostForecaster()
    forecaster.fit(df)
    forecast_df = forecaster.forecast()
    
    # Root cause analysis
    logger.info("\n🟡 ROOT CAUSE ANALYSIS")
    logger.info("-" * 70)
    root_causes = RootCauseAnalyzer.analyze(df)
    
    # Save outputs
    logger.info("\n💾 Saving outputs for Person 3 & 4...")
    os.makedirs("data", exist_ok=True)
    
    df.to_csv(ML_RESULTS_CSV, index=False)
    logger.info(f"✅ Saved: {ML_RESULTS_CSV}")
    
    if not forecast_df.empty:
        forecast_df.to_csv(FORECAST_CSV, index=False)
        logger.info(f"✅ Saved: {FORECAST_CSV}")
    
    if not root_causes.empty:
        root_causes.to_csv(ROOT_CAUSES_CSV, index=False)
        logger.info(f"✅ Saved: {ROOT_CAUSES_CSV}")
    
    logger.info("=" * 70)
    logger.info("✅ PERSON 2 COMPLETE - Data ready for Person 3 & 4")
    logger.info("=" * 70)
    
    return df, forecast_df, root_causes

if __name__ == "__main__":
    run_person2_pipeline()