"""
Test that all 4 modules integrate properly
Run this to verify everything works together
"""

import os
import sys
import pandas as pd

def test_all():
    """Run all integration tests"""
    print("\n" + "=" * 70)
    print("INTEGRATION TEST: All 4 Modules")
    print("=" * 70)
    
    results = {}
    
    # Test 1: Person 1's output
    print("\n✅ TEST 1: Person 1's Output")
    print("-" * 70)
    if os.path.exists('data/cloud_costs.db'):
        try:
            import sqlite3
            conn = sqlite3.connect('data/cloud_costs.db')
            count = pd.read_sql("SELECT COUNT(*) as cnt FROM cloud_costs", conn)['cnt'][0]
            conn.close()
            print(f"✅ PASS: Database exists with {count} rows")
            results['Person 1'] = True
        except Exception as e:
            print(f"❌ FAIL: {e}")
            results['Person 1'] = False
    else:
        print("❌ FAIL: Database not found")
        print("   Action: Run python main.py --person 1")
        results['Person 1'] = False
    
    # Test 2: Person 2's output
    print("\n✅ TEST 2: Person 2's Output")
    print("-" * 70)
    person2_files = [
        'data/ml_results.csv',
        'data/forecast.csv',
        'data/root_causes.csv'
    ]
    
    all_exist = True
    for file in person2_files:
        if os.path.exists(file):
            rows = len(pd.read_csv(file))
            print(f"✅ {file} ({rows} rows)")
        else:
            print(f"❌ {file} NOT FOUND")
            all_exist = False
    
    if not all_exist:
        print("   Action: Run python main.py --person 2")
    results['Person 2'] = all_exist
    
    # Test 3: Person 3's output
    print("\n✅ TEST 3: Person 3's Output")
    print("-" * 70)
    if os.path.exists('logs/automation_actions.log'):
        with open('logs/automation_actions.log', 'r') as f:
            content = f.read()
        print(f"✅ Log file exists ({len(content)} bytes)")
        results['Person 3'] = True
    else:
        print("❌ Log file NOT FOUND")
        print("   Action: Run python main.py --person 3")
        results['Person 3'] = False
    
    # Test 4: All data readable by Person 4
    print("\n✅ TEST 4: Person 4 Integration")
    print("-" * 70)
    person4_ready = all([
        os.path.exists('data/ml_results.csv'),
        os.path.exists('data/forecast.csv'),
        os.path.exists('data/root_causes.csv'),
        os.path.exists('logs/automation_actions.log')
    ])
    
    if person4_ready:
        print("✅ All data available for Person 4 dashboard")
        results['Person 4'] = True
    else:
        print("❌ Missing data for Person 4")
        results['Person 4'] = False
    
    # Summary
    print("\n" + "=" * 70)
    print("SUMMARY")
    print("=" * 70)
    
    for person, passed in results.items():
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{status}: {person}")
    
    all_passed = all(results.values())
    
    if all_passed:
        print("\n🎉 ALL INTEGRATION TESTS PASSED!")
        print("✅ System is ready for judges")
    else:
        print("\n⚠️  SOME TESTS FAILED")
        print("Run: python main.py to complete the pipeline")
    
    return all_passed

if __name__ == "__main__":
    success = test_all()
    sys.exit(0 if success else 1)