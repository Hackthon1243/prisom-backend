"""
Shared configuration - used by all 4 modules
Change settings here, affects all modules
"""

import os
from datetime import datetime, timedelta

# ============================================================================
# AWS CONFIGURATION
# ============================================================================
AWS_ACCESS_KEY = os.getenv("AWS_ACCESS_KEY_ID", "your_access_key_here")
AWS_SECRET_KEY = os.getenv("AWS_SECRET_ACCESS_KEY", "your_secret_key_here")
AWS_REGION = "us-east-1"

# Toggle: Real AWS or synthetic data
USE_REAL_AWS_DATA = False

# ============================================================================
# DATA PATHS (where files go)
# ============================================================================
DATA_DIR = "data"
LOGS_DIR = "logs"
DB_FILE = f"{DATA_DIR}/cloud_costs.db"
ML_RESULTS_CSV = f"{DATA_DIR}/ml_results.csv"
FORECAST_CSV = f"{DATA_DIR}/forecast.csv"
ROOT_CAUSES_CSV = f"{DATA_DIR}/root_causes.csv"
AUTOMATION_LOG = f"{LOGS_DIR}/automation_actions.log"

# Create directories if they don't exist
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(LOGS_DIR, exist_ok=True)

# ============================================================================
# PERSON 1 SETTINGS (Data Pipeline)
# ============================================================================
DAYS_LOOKBACK = 30
ANALYSIS_START_DATE = (datetime.now() - timedelta(days=DAYS_LOOKBACK)).strftime("%Y-%m-%d")
ANALYSIS_END_DATE = datetime.now().strftime("%Y-%m-%d")

# ============================================================================
# PERSON 2 SETTINGS (ML)
# ============================================================================
ANOMALY_CONTAMINATION = 0.05
ANOMALY_RANDOM_STATE = 42
ANOMALY_THRESHOLD = -0.5
PROPHET_FORECAST_PERIODS = 7
PROPHET_INTERVAL_WIDTH = 0.95
MIN_CPU_THRESHOLD = 5  # FIXED: Was missing

# ============================================================================
# PERSON 3 SETTINGS (Automation)
# ============================================================================
DRY_RUN_MODE = True
ENABLE_ACTUAL_TERMINATION = False
REQUIRE_APPROVAL = True
AUTO_STOP_IDLE_INSTANCES = True
IDLE_THRESHOLD_HOURS = 24
MIN_INSTANCE_AGE_DAYS = 7

# ============================================================================
# PERSON 4 SETTINGS (Dashboard)
# ============================================================================
STREAMLIT_PORT = 8501
STREAMLIT_THEME = "dark"
DASHBOARD_REFRESH_SECONDS = 5
COLORS = {
    "normal": "#00D9FF",
    "anomaly": "#FF1744",
    "forecast": "#76FF03",
    "saved": "#00E676",
    "background": "#0A0E27",
    "text": "#FFFFFF",
}

# ============================================================================
# LOGGING
# ============================================================================
LOG_LEVEL = "INFO"
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

# ============================================================================
# DEMO MODE (for live presentation)
# ============================================================================
DEMO_MODE = False
DEMO_SPIKE_SIZE = 500

print("✅ Config loaded")